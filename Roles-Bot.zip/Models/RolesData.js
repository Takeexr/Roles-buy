module.exports = {
  role1: {
    Name: "🜲 || Legend Seller",
    Id: "1220756324091170826",
    Description: `

        `,
    Price: "60000",
  },
  role2: {
    Name: "🜲 || VIP Seller",
    Id: "1220756325919752372",
    Description: `

        `,
    Price: "120000",
  },
  role3: {
    Name: "🜲 || Five Seller",
    Id: "1220756327849267350",
    Description: `

        `,
    Price: "200000",
  },
  role4: {
    Name: "🜲 || Five+ Seller",
    Id: "1220756329547694090",
    Description: `

        `,
    Price: "500000",
  },
  role5: {
    Name: "",
    Id: "",
    Description: `

        `,
    Price: "",
  },
}