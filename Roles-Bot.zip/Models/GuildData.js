module.exports = {
  Guild: {
    GuildId: "1220748190609834004",
    Probot: "282859044593598464",
    Owner: "987800638484250734"
  },
  Channels: {
    Log: "1226969216616370237"
  }
}